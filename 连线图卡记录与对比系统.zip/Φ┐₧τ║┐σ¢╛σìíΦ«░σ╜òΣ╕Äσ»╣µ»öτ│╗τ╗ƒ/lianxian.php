<?php
/*
Plugin Name: 连线图卡记录与对比系统
Plugin URI: 
Description: 实现连线图卡的记录和对比功能
Version: 1.0
Author: 你的名字
Author URI: 
License: GPL2
*/

// 检查WordPress环境
if (!defined('ABSPATH')) {
    exit;
}

class WiredCardSystem {
    public function __construct() {
        add_action('admin_menu', array($this, 'add_menu_page'));
        add_shortcode('wired_card_system', array($this, 'display_wired_card_system'));
        add_shortcode('wired_card_profile', array($this, 'display_profile_form'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_scripts'));
        add_action('wp_ajax_wired_card_submit', array($this, 'wired_card_submit'));
        add_action('wp_ajax_nopriv_wired_card_submit', array($this, 'wired_card_submit'));
        add_action('wp_ajax_wired_card_save_thumbnail', array($this, 'save_thumbnail'));
        add_action('admin_init', array($this, 'register_settings'));
        add_action('wp_ajax_wired_card_set_nickname', array($this, 'set_nickname'));
        add_action('wp_ajax_wired_card_get_card_detail', array($this, 'get_card_detail'));
        add_action('wp_ajax_wired_card_get_ranking', array($this, 'get_ranking'));
        add_action('wp_ajax_wired_card_get_admin_stats', array($this, 'get_admin_stats'));
        add_action('wp_ajax_wired_card_save_profile', array($this, 'save_profile'));
    }

    // 添加管理菜单页面
    public function add_menu_page() {
        add_menu_page(
            '连线图卡记录与对比系统',
            '连线图卡系统',
            'manage_options',
            'wired-card-system',
            array($this, 'display_admin_page'),
            'dashicons-images-alt2',
            30
        );
        
        add_submenu_page(
            'wired-card-system',
            '图卡设置',
            '图卡设置',
            'manage_options',
            'wired-card-settings',
            array($this, 'display_settings_page')
        );
        
        add_submenu_page(
            'wired-card-system',
            '用户管理',
            '用户管理',
            'manage_options',
            'wired-card-users',
            array($this, 'display_users_page')
        );
    }

    // 管理页面内容
    public function display_admin_page() {
        echo '<div class="wrap">';
        echo '<h1>连线图卡记录与对比系统管理</h1>';
        
        // 显示基本统计信息
        global $wpdb;
        $table_name = $wpdb->prefix. 'wired_card_records';
        $total_records = $wpdb->get_var("SELECT COUNT(*) FROM $table_name");
        $total_users = $wpdb->get_var("SELECT COUNT(DISTINCT nickname) FROM $table_name");
        $completed_pages = $wpdb->get_var("SELECT COUNT(DISTINCT page) FROM $table_name");
        
        echo '<div class="stats-card">';
        echo '<div class="stat-item"><span class="stat-number">'. $total_records. '</span><span class="stat-label">总记录数</span></div>';
        echo '<div class="stat-item"><span class="stat-number">'. $total_users. '</span><span class="stat-label">参与学员</span></div>';
        echo '<div class="stat-item"><span class="stat-number">'. $completed_pages. '/100</span><span class="stat-label">完成页面</span></div>';
        echo '</div>';
        
        // 显示排行榜图表
        echo '<div class="chart-container">';
        echo '<h3>学员表现排行</h3>';
        echo '<canvas id="admin-ranking-chart" width="400" height="200"></canvas>';
        echo '</div>';
        
        echo '</div>';
    }

    // 设置页面内容
    public function display_settings_page() {
        echo '<div class="wrap">';
        echo '<h1>连线图卡设置</h1>';
        
        echo '<form method="post" action="options.php">';
        settings_fields('wired_card_settings');
        do_settings_sections('wired_card_settings');
        submit_button();
        echo '</form>';
        
        echo '<h2>图卡缩略图设置</h2>';
        echo '<div id="thumbnail-settings" class="thumbnail-settings">';
        for ($i = 1; $i <= 100; $i++) {
            $thumbnail_url = plugins_url('images/画板 '. $i. '.jpg', __FILE__);
            $thumbnail_path = dirname(__FILE__). '/images/画板 '. $i. '.jpg';
            
            echo '<div class="thumbnail-setting">';
            echo '<h3>第 '. $i. ' 页</h3>';
            echo '<div class="thumbnail-preview">';
            echo file_exists($thumbnail_path)? '<img src="'. $thumbnail_url. '" alt="预览" class="preview-image" />' : '<div class="no-preview">暂无预览</div>';
            echo '</div>';
            echo '<input type="hidden" name="thumbnail_id" class="thumbnail-id" value="'. $thumbnail_id. '">';
            echo '<button type="button" class="select-thumbnail button" data-page="'. $i. '">选择缩略图</button>';
            echo '<button type="button" class="remove-thumbnail button" data-page="'. $i. '">移除</button>';
            echo '</div>';
        }
        echo '</div>';
        echo '</div>';
    }

    // 注册设置选项
    public function register_settings() {
        register_setting('wired_card_settings', 'wired_card_error_min', array('default' => 0));
        register_setting('wired_card_settings', 'wired_card_error_max', array('default' => 100));
        register_setting('wired_card_settings', 'wired_card_time_min', array('default' => 0));
        register_setting('wired_card_settings', 'wired_card_time_max', array('default' => 3600));
        
        add_settings_section(
            'wired_card_main_settings',
            '基本设置',
            array($this, 'settings_section_callback'),
            'wired_card_settings'
        );
        
        add_settings_field(
            'error_min',
            '最小错误数',
            array($this, 'error_min_callback'),
            'wired_card_settings',
            'wired_card_main_settings'
        );
        
        add_settings_field(
            'error_max',
            '最大错误数',
            array($this, 'error_max_callback'),
            'wired_card_settings',
            'wired_card_main_settings'
        );
        
        add_settings_field(
            'time_min',
            '最小用时(秒)',
            array($this, 'time_min_callback'),
            'wired_card_settings',
            'wired_card_main_settings'
        );
        
        add_settings_field(
            'time_max',
            '最大用时(秒)',
            array($this, 'time_max_callback'),
            'wired_card_settings',
            'wired_card_main_settings'
        );
    }

    // 设置回调函数
    public function settings_section_callback() {
        echo '配置图卡记录的基本参数';
    }

    public function error_min_callback() {
        echo '<input type="number" name="wired_card_error_min" value="'. get_option('wired_card_error_min') .'">';
    }

    public function error_max_callback() {
        echo '<input type="number" name="wired_card_error_max" value="'. get_option('wired_card_error_max') .'">';
    }

    public function time_min_callback() {
        echo '<input type="number" name="wired_card_time_min" value="'. get_option('wired_card_time_min') .'">';
    }

    public function time_max_callback() {
        echo '<input type="number" name="wired_card_time_max" value="'. get_option('wired_card_time_max') .'">';
    }

    // 前端页面内容
    public function display_wired_card_system() {
        ob_start();
        
        // 检查用户是否登录
        if (!is_user_logged_in()) {
            echo '<div class="wired-card-message error">请先<a href="/zhanghaoshezhi/">登陆</a>以使用连线图卡系统</div>';
            return ob_get_clean();
        }
        
        // 检查用户资料是否已设置
        global $wpdb;
        $profile = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}wired_card_user_profiles WHERE user_id = %d", 
            get_current_user_id()
        ));
        
        if (empty($profile)) {
            echo '<div class="wired-card-message error">';
            echo '请先<a href="/lxuser/">设置您的学员资料</a>以使用连线图卡系统';
            echo '</div>';
            return ob_get_clean();
        } else {
            echo '<div class="wired-card-welcome">';
            echo '<h2>欢迎回来，'. esc_html($profile->nickname). '</h2>';
            echo '<p>选择要练习的图卡页面</p>';
            echo '</div>';
            
            // 显示图卡选择器
            echo '<div class="wired-card-selector">';
            for ($i = 1; $i <= 100; $i++) {
                $thumbnail_url = plugins_url('images/画板 '. $i. '.jpg', __FILE__);
            $thumbnail_path = dirname(__FILE__). '/images/画板 '. $i. '.jpg';
            $thumbnail_url = file_exists($thumbnail_path)? $thumbnail_url : 'https://picsum.photos/seed/card'. $i. '/200/200';
            
            echo '<div class="card-item" data-page="'. $i. '">';
            echo '<div class="card-thumbnail">';
            echo '<img src="'. esc_url($thumbnail_url). '" alt="第 '. $i. ' 页">';
            echo '</div>';
                echo '<div class="card-info">';
                echo '<h3>第 '. $i. ' 页</h3>';
                
                // 检查是否已有记录
                global $wpdb;
                $table_name = $wpdb->prefix. 'wired_card_records';
                $record = $wpdb->get_row(
                    $wpdb->prepare(
                        "SELECT * FROM $table_name WHERE nickname = %s AND page = %d",
                        $profile->nickname,
                        $i
                    )
                );
                
                if ($record) {
                    echo '<div class="card-record">';
                    echo '<span class="record-label">您的记录:</span>';
                    echo '<span class="record-error">错误: '. $record->error. '</span>';
                    echo '<span class="record-time">用时: '. $record->time. '秒</span>';
                    echo '</div>';
                }
                
                echo '<button class="btn btn-secondary open-card" data-page="'. $i. '">查看详情</button>';
                echo '</div>';
                echo '</div>';
            }
            echo '</div>';
            
            // 图卡详情模态框
            echo '<div id="card-detail-modal" class="modal">';
            echo '<div class="modal-content">';
            echo '<span class="close-modal">&times;</span>';
            echo '<div id="modal-content-inner"></div>';
            echo '</div>';
            echo '</div>';
            
            // 排行榜部分
            echo '<div class="wired-card-ranking">';
            echo '<h2>排行榜</h2>';
            echo '<div class="chart-container">';
            echo '<canvas id="ranking-chart"></canvas>';
            echo '</div>';
            echo '<div id="ranking-table">';
            echo '<table class="ranking-table">';
            echo '<thead><tr><th>排名</th><th>学员昵称</th><th>完成页数</th></tr></thead>';
            echo '<tbody id="ranking-table-body"></tbody>';
            echo '</table>';
            echo '</div>';
            echo '</div>';
        }
        
        return ob_get_clean();
    }

    // 处理提交记录
    public function wired_card_submit() {
        // 安全验证
        check_ajax_referer('wired_card_nonce', 'nonce');
        
        if (!is_user_logged_in()) {
            wp_send_json_error(array('message' => '请先登录'));
        }
        
        global $wpdb;
        $profile = $wpdb->get_row($wpdb->prepare(
            "SELECT nickname FROM {$wpdb->prefix}wired_card_user_profiles WHERE user_id = %d", 
            get_current_user_id()
        ));
        
        if (empty($profile)) {
            wp_send_json_error(array('message' => '请先设置学员资料'));
        }
        
        $nickname = $profile->nickname;
        
        $page = isset($_POST['page'])? intval($_POST['page']) : 0;
        $error = isset($_POST['error'])? intval($_POST['error']) : 0;
        $time = isset($_POST['time'])? intval($_POST['time']) : 0;
        
        // 数据验证
        $error_min = get_option('wired_card_error_min', 0);
        $error_max = get_option('wired_card_error_max', 100);
        $time_min = get_option('wired_card_time_min', 0);
        $time_max = get_option('wired_card_time_max', 3600);
        
        if ($page < 1 || $page > 100) {
            wp_send_json_error(array('message' => '无效的页码'));
        }
        
        if ($error < $error_min || $error > $error_max) {
            wp_send_json_error(array('message' => '错误数必须在 '. $error_min. ' 到 '. $error_max. ' 之间'));
        }
        
        if ($time < $time_min || $time > $time_max) {
            wp_send_json_error(array('message' => '用时必须在 '. $time_min. ' 到 '. $time_max. ' 秒之间'));
        }
        
        // 存储记录到数据库
        global $wpdb;
        $table_name = $wpdb->prefix. 'wired_card_records';
        
        // 检查是否已有记录
        $existing_record = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT * FROM $table_name WHERE nickname = %s AND page = %d",
                $nickname,
                $page
            )
        );
        
        if ($existing_record) {
            // 更新记录
            $wpdb->update(
                $table_name,
                array(
                    'error' => $error,
                    'time' => $time,
                    'created_at' => current_time('mysql')
                ),
                array(
                    'id' => $existing_record->id
                ),
                array(
                    '%d',
                    '%d',
                    '%s'
                )
            );
        } else {
            // 插入新记录
            $wpdb->insert(
                $table_name,
                array(
                    'nickname' => $nickname,
                    'page' => $page,
                    'error' => $error,
                    'time' => $time
                ),
                array(
                    '%s',
                    '%d',
                    '%d',
                    '%d'
                )
            );
        }
        
        // 获取排行榜数据
        $ranking_data = $this->get_ranking_data($page);
        
        wp_send_json_success(array(
            'message' => '记录提交成功',
            'ranking' => $ranking_data
        ));
    }

    // 保存缩略图设置
    public function save_thumbnail() {
        // 安全验证
        check_ajax_referer('wired_card_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => '权限不足'));
        }
        
        $page = isset($_POST['page'])? intval($_POST['page']) : 0;
        $thumbnail_id = isset($_POST['thumbnail_id'])? intval($_POST['thumbnail_id']) : 0;
        
        if ($page < 1 || $page > 100) {
            wp_send_json_error(array('message' => '无效的页码'));
        }
        
        update_option('wired_card_thumbnail_'. $page, $thumbnail_id);
        
        wp_send_json_success(array('message' => '缩略图设置已保存'));
    }

    // 设置学员资料 (已弃用，改为使用save_profile)
    public function set_nickname() {
        wp_send_json_error(array('message' => '请使用资料页面设置学员信息'));
    }

    // 获取图卡详情
    public function get_card_detail() {
        // 安全验证
        check_ajax_referer('wired_card_nonce', 'nonce');
        
        $page = isset($_POST['page'])? intval($_POST['page']) : 0;
        
        if ($page < 1 || $page > 100) {
            wp_send_json_error(array('message' => '无效的页码'));
        }
        
        $thumbnail_url = plugins_url('images/画板 '. $page. '.jpg', __FILE__);
        $thumbnail_path = dirname(__FILE__). '/images/画板 '. $page. '.jpg';
        $thumbnail_url = file_exists($thumbnail_path)? $thumbnail_url : 'https://picsum.photos/seed/card'. $page. '/600/400';
        
        // 获取用户记录
        $user_record = array();
        if (is_user_logged_in()) {
            global $wpdb;
            $profile = $wpdb->get_row($wpdb->prepare(
                "SELECT nickname FROM {$wpdb->prefix}wired_card_user_profiles WHERE user_id = %d", 
                get_current_user_id()
            ));
            
            if (!empty($profile)) {
                $table_name = $wpdb->prefix. 'wired_card_records';
                $user_record = $wpdb->get_row(
                    $wpdb->prepare(
                        "SELECT * FROM $table_name WHERE nickname = %s AND page = %d",
                        $profile->nickname,
                        $page
                    ),
                    ARRAY_A
                );
            }
        }
        
        // 获取排行榜数据
        $ranking_data = $this->get_ranking_data($page);
        
        $response = array(
            'page' => $page,
            'thumbnail_url' => $thumbnail_url,
            'user_record' => $user_record,
            'ranking' => $ranking_data
        );
        
        wp_send_json_success($response);
    }

    // 获取排行榜数据
    public function get_ranking_data($page) {
        global $wpdb;
        $table_name = $wpdb->prefix. 'wired_card_records';
        
        // 获取特定页面的排行榜
        $page_ranking = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT r.nickname, r.error, r.time,
                        p.child_age, p.city, p.school
                 FROM $table_name r
                 LEFT JOIN {$wpdb->prefix}wired_card_user_profiles p ON r.nickname = p.nickname
                 WHERE r.page = %d 
                 ORDER BY r.error ASC, r.time ASC 
                 LIMIT 10",
                $page
            ),
            ARRAY_A
        );
        
        // 获取总排行榜(按完成页数、错误数、用时排序)
        $total_ranking = $wpdb->get_results(
            "SELECT r.nickname, 
                    SUM(r.error) as total_error, 
                    SUM(r.time) as total_time,
                    COUNT(DISTINCT r.page) as completed_pages,
                    p.child_age,
                    p.city,
                    p.school
             FROM $table_name r
             LEFT JOIN {$wpdb->prefix}wired_card_user_profiles p ON r.nickname = p.nickname
             GROUP BY r.nickname 
             ORDER BY completed_pages DESC
             LIMIT 10",
            ARRAY_A
        );
        
        return array(
            'page_ranking' => $page_ranking,
            'total_ranking' => $total_ranking
        );
    }

    // 获取排行榜数据（AJAX）
    public function get_ranking() {
        // 安全验证
        check_ajax_referer('wired_card_nonce', 'nonce');
        
        $ranking_data = $this->get_ranking_data(0); // 0表示获取所有页面的总排行
        
        wp_send_json_success(array(
            'total_ranking' => $ranking_data['total_ranking']
        ));
    }

    // 获取管理统计数据
    public function get_admin_stats() {
        // 安全验证
        check_ajax_referer('wired_card_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => '权限不足'));
        }
        
        global $wpdb;
        $table_name = $wpdb->prefix. 'wired_card_records';
        
        // 获取各页面完成次数
        $page_counts = $wpdb->get_results(
            "SELECT page, COUNT(*) as count 
             FROM $table_name 
             GROUP BY page 
             ORDER BY page ASC",
            ARRAY_A
        );
        
        // 获取用户资料统计
        $user_stats = $wpdb->get_results(
            "SELECT 
                COUNT(DISTINCT p.user_id) as total_users,
                AVG(p.child_age) as avg_age,
                COUNT(DISTINCT p.city) as city_count
             FROM {$wpdb->prefix}wired_card_user_profiles p
             JOIN $table_name r ON p.nickname = r.nickname",
            ARRAY_A
        );
        
        // 准备图表数据
        $labels = array();
        $completion_counts = array();
        
        for ($i = 1; $i <= 100; $i++) {
            $labels[] = '第'. $i. '页';
            $found = false;
            
            foreach ($page_counts as $count) {
                if ($count['page'] == $i) {
                    $completion_counts[] = $count['count'];
                    $found = true;
                    break;
                }
            }
            
            if (!$found) {
                $completion_counts[] = 0;
            }
        }
        
        wp_send_json_success(array(
            'labels' => $labels,
            'completion_counts' => $completion_counts,
            'user_stats' => $user_stats[0] ?? array()
        ));
    }

    // 加载前端脚本和样式
    public function enqueue_scripts() {
        wp_enqueue_style('wired-card-style', plugins_url('assets/css/style.css', __FILE__), array(), '1.0.0');
        
        // 注册Chart.js并添加备用本地版本
        wp_register_script('chart-js', 
            'https://cdn.jsdelivr.net/npm/chart.js@4.4.8/dist/chart.umd.min.js', 
            array(), 
            '4.4.8', 
            true);
        
        // 添加Chart.js加载失败的回退方案
        wp_add_inline_script('chart-js', 
            'if(typeof Chart === "undefined") {
                console.error("Chart.js加载失败，尝试加载本地版本");
                document.write(\'<script src="'.plugins_url('assets/js/chart.umd.min.js', __FILE__).'"><\/script>\');
            }'
        );
        
        // 确保Chart.js在脚本之前加载
        wp_enqueue_script('wired-card-script', 
            plugins_url('assets/js/script.js', __FILE__), 
            array('jquery', 'chart-js'), 
            '1.0.0', 
            true);
        
        wp_localize_script('wired-card-script', 'wiredCard', array(
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('wired_card_nonce'),
            'errorMin' => get_option('wired_card_error_min', 0),
            'errorMax' => get_option('wired_card_error_max', 100),
            'timeMin' => get_option('wired_card_time_min', 0),
            'timeMax' => get_option('wired_card_time_max', 3600)
        ));

        // 只在用户资料页面加载额外的脚本和样式
        if (is_page() && has_shortcode(get_post()->post_content, 'wired_card_profile')) {
            wp_enqueue_style('wired-card-profile-style', plugins_url('assets/css/profile.css', __FILE__), array(), '1.0.0');
            wp_enqueue_script('wired-card-profile', plugins_url('assets/js/profile.js', __FILE__), array('jquery'), '1.0.0', true);
            wp_localize_script('wired-card-profile', 'wiredCardProfile', array(
                'ajaxUrl' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('wired_card_profile_nonce')
            ));
        }
    }
    
    // 处理图片上传
    public function handle_thumbnail_upload() {
        check_ajax_referer('wired_card_nonce', 'nonce');
        
        if (!function_exists('wp_handle_upload')) {
            require_once(ABSPATH . 'wp-admin/includes/file.php');
        }
        
        $uploadedfile = $_FILES['file'];
        $upload_overrides = array('test_form' => false);
        
        $movefile = wp_handle_upload($uploadedfile, $upload_overrides);
        
        if ($movefile && !isset($movefile['error'])) {
            wp_send_json_success(array(
                'url' => $movefile['url']
            ));
        } else {
            wp_send_json_error(array(
                'message' => $movefile['error']
            ));
        }
    }

    // 显示用户管理页面
    public function display_users_page() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'wired_card_user_profiles';
        
        // 检查表是否存在
        if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") != $table_name) {
            echo '<div class="notice notice-error"><p>用户资料表不存在，请重新激活插件</p></div>';
            return;
        }
        
        // 处理用户编辑请求
        if (isset($_GET['action']) && $_GET['action'] === 'edit' && isset($_GET['user_id'])) {
            $user_id = intval($_GET['user_id']);
            $profile = $wpdb->get_row($wpdb->prepare(
                "SELECT * FROM $table_name WHERE user_id = %d", 
                $user_id
            ));
            
            if (!$profile) {
                wp_die('用户不存在');
            }
            
            $user = get_userdata($user_id);
            
            // 处理表单提交
            if (isset($_POST['submit'])) {
                check_admin_referer('edit_user_profile_' . $user_id);
                
                $data = [
                    'nickname' => sanitize_text_field($_POST['nickname']),
                    'child_age' => intval($_POST['child_age']),
                    'city' => isset($_POST['city']) ? sanitize_text_field($_POST['city']) : null,
                    'school' => isset($_POST['school']) ? sanitize_text_field($_POST['school']) : null
                ];
                
                if (empty($data['nickname']) || empty($data['child_age'])) {
                    echo '<div class="notice notice-error"><p>请填写必填字段</p></div>';
                } else {
                    $result = $wpdb->update($table_name, $data, ['user_id' => $user_id]);
                    
                    if ($result !== false) {
                        echo '<div class="notice notice-success"><p>用户资料已更新</p></div>';
                        $profile = $wpdb->get_row($wpdb->prepare(
                            "SELECT * FROM $table_name WHERE user_id = %d", 
                            $user_id
                        ));
                    } else {
                        echo '<div class="notice notice-error"><p>更新失败</p></div>';
                    }
                }
            }
            
            echo '<div class="wrap">';
            echo '<h1>编辑用户资料</h1>';
            echo '<form method="post">';
            wp_nonce_field('edit_user_profile_' . $user_id);
            
            echo '<table class="form-table">';
            echo '<tr>
                    <th><label for="nickname">学员昵称</label></th>
                    <td><input type="text" name="nickname" id="nickname" value="' . esc_attr($profile->nickname) . '" class="regular-text" required></td>
                  </tr>';
            echo '<tr>
                    <th><label for="child_age">儿童年龄</label></th>
                    <td><input type="number" name="child_age" id="child_age" value="' . esc_attr($profile->child_age) . '" min="3" max="18" class="regular-text" required></td>
                  </tr>';
            echo '<tr>
                    <th><label for="city">所在城市</label></th>
                    <td><input type="text" name="city" id="city" value="' . esc_attr($profile->city) . '" class="regular-text"></td>
                  </tr>';
            echo '<tr>
                    <th><label for="school">所在学校</label></th>
                    <td><input type="text" name="school" id="school" value="' . esc_attr($profile->school) . '" class="regular-text"></td>
                  </tr>';
            echo '</table>';
            
            submit_button('更新资料');
            echo '<a href="' . admin_url('admin.php?page=wired-card-users') . '" class="button">返回用户列表</a>';
            echo '</form>';
            echo '</div>';
            
            return;
        }
        
        // 处理用户删除请求
        if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['user_id'])) {
            if (!wp_verify_nonce($_GET['_wpnonce'], 'delete_user_' . $_GET['user_id'])) {
                wp_die('安全验证失败');
            }
            
            $wpdb->delete($table_name, ['user_id' => intval($_GET['user_id'])]);
            echo '<div class="notice notice-success"><p>用户已删除</p></div>';
        }
        
        // 获取所有用户资料
        $query = "
            SELECT p.*, u.user_login, u.user_email 
            FROM $table_name p
            LEFT JOIN {$wpdb->users} u ON p.user_id = u.ID
            ORDER BY p.updated_at DESC
        ";
        
        // 调试输出SQL查询
        error_log("User profiles query: " . $query);
        
        $users = $wpdb->get_results($query);
        
        // 检查查询结果
        if ($wpdb->last_error) {
            error_log("Database error: " . $wpdb->last_error);
            echo '<div class="notice notice-error"><p>数据库查询错误: ' . esc_html($wpdb->last_error) . '</p></div>';
        }
        
        // 调试输出用户数量
        error_log("Found " . count($users) . " user profiles");
        
        echo '<div class="wrap">';
        echo '<h1>用户管理</h1>';
        
        echo '<table class="wp-list-table widefat fixed striped">';
        echo '<thead><tr>
                <th>用户ID</th>
                <th>用户名</th>
                <th>邮箱</th>
                <th>学员昵称</th>
                <th>儿童年龄</th>
                <th>所在城市</th>
                <th>所在学校</th>
                <th>操作</th>
              </tr></thead>';
        echo '<tbody>';
        
        foreach ($users as $user) {
            $edit_url = admin_url('admin.php?page=wired-card-users&action=edit&user_id=' . $user->user_id);
            $delete_url = wp_nonce_url(
                admin_url('admin.php?page=wired-card-users&action=delete&user_id=' . $user->user_id),
                'delete_user_' . $user->user_id
            );
            
            echo '<tr>';
            echo '<td>' . esc_html($user->user_id) . '</td>';
            echo '<td>' . esc_html($user->user_login) . '</td>';
            echo '<td>' . esc_html($user->user_email) . '</td>';
            echo '<td>' . esc_html($user->nickname) . '</td>';
            echo '<td>' . esc_html($user->child_age) . '</td>';
            echo '<td>' . esc_html($user->city) . '</td>';
            echo '<td>' . esc_html($user->school) . '</td>';
            echo '<td>
                    <a href="' . esc_url($edit_url) . '" class="button">编辑</a>
                    <a href="' . esc_url($delete_url) . '" class="button button-link-delete">删除</a>
                  </td>';
            echo '</tr>';
        }
        
        echo '</tbody></table>';
        echo '</div>';
    }

    // 显示用户资料表单
    public function display_profile_form() {
        if (!is_user_logged_in()) {
            return '<p>请先登录以编辑您的资料</p>';
        }

        global $wpdb;
        $user_id = get_current_user_id();
        $profile = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}wired_card_user_profiles WHERE user_id = %d", 
            $user_id
        ));

        ob_start();
        ?>
        <div class="wired-card-profile-form">
            <h3>用户资料</h3>
            <form id="wired-card-profile-form">
                <div class="form-group">
                    <label for="nickname">学员昵称*</label>
                    <input type="text" id="nickname" name="nickname" 
                           value="<?php echo esc_attr($profile->nickname ?? ''); ?>" required>
                </div>
                <div class="form-group">
                    <label for="child_age">儿童年龄*</label>
                    <input type="number" id="child_age" name="child_age" min="3" max="18"
                           value="<?php echo esc_attr($profile->child_age ?? ''); ?>" required>
                </div>
                <div class="form-group">
                    <label for="city">所在城市</label>
                    <input type="text" id="city" name="city" 
                           value="<?php echo esc_attr($profile->city ?? ''); ?>">
                </div>
                <div class="form-group">
                    <label for="school">所在学校</label>
                    <input type="text" id="school" name="school" 
                           value="<?php echo esc_attr($profile->school ?? ''); ?>">
                </div>
                <button type="submit" class="button">保存资料</button>
                <div class="profile-message"></div>
            </form>
        </div>
        <?php
        return ob_get_clean();
    }

    // 保存用户资料 (AJAX处理)
    public function save_profile() {
        if (!is_user_logged_in()) {
            wp_send_json_error('请先登录');
        }

        check_ajax_referer('wired_card_profile_nonce', '_wpnonce');

        $user_id = get_current_user_id();
        $data = [
            'user_id' => $user_id,
            'nickname' => sanitize_text_field($_POST['nickname']),
            'child_age' => intval($_POST['child_age']),
            'city' => isset($_POST['city']) ? sanitize_text_field($_POST['city']) : null,
            'school' => isset($_POST['school']) ? sanitize_text_field($_POST['school']) : null
        ];

        if (empty($data['nickname']) || empty($data['child_age'])) {
            wp_send_json_error('请填写必填字段');
        }

        global $wpdb;
        $table = $wpdb->prefix . 'wired_card_user_profiles';
        
        $exists = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM $table WHERE user_id = %d", 
            $user_id
        ));

        if ($exists) {
            $result = $wpdb->update($table, $data, ['user_id' => $user_id]);
        } else {
            $result = $wpdb->insert($table, $data);
        }

        if ($result === false) {
            wp_send_json_error('保存失败: ' . $wpdb->last_error);
        }

        wp_send_json_success('资料已保存');
    }

    // 加载管理页面脚本和样式
    public function enqueue_admin_scripts($hook) {
        if ($hook != 'toplevel_page_wired-card-system' && $hook != 'wired-card-system_page_wired-card-settings') {
            return;
        }
        
        wp_enqueue_media();
        wp_enqueue_style('wired-card-admin-style', plugins_url('assets/css/admin-style.css', __FILE__), array(), '1.0.0');
        wp_enqueue_script('chart-js', 'https://cdn.jsdelivr.net/npm/chart.js@4.4.8/dist/chart.umd.min.js', array(), '4.4.8', true);
        wp_enqueue_script('wired-card-admin-script', plugins_url('assets/js/admin-script.js', __FILE__), array('jquery', 'chart-js'), '1.0.0', true);
        
        wp_localize_script('wired-card-admin-script', 'wiredCardAdmin', array(
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('wired_card_nonce')
        ));
    }
}

// 初始化插件
$wired_card_system = new WiredCardSystem();

// 创建数据库表
function wired_card_create_table() {
    global $wpdb;
    $records_table = $wpdb->prefix. 'wired_card_records';
    $profiles_table = $wpdb->prefix. 'wired_card_user_profiles';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $records_table (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        nickname varchar(255) NOT NULL,
        page int(11) NOT NULL,
        error int(11) NOT NULL,
        time int(11) NOT NULL,
        created_at datetime DEFAULT CURRENT_TIMESTAMP NOT NULL,
        PRIMARY KEY  (id)
    ) $charset_collate;
    
    CREATE TABLE $profiles_table (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        user_id bigint(20) NOT NULL,
        nickname varchar(255) NOT NULL,
        child_age int(11) NOT NULL,
        city varchar(255) DEFAULT NULL,
        school varchar(255) DEFAULT NULL,
        created_at datetime DEFAULT CURRENT_TIMESTAMP NOT NULL,
        updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP NOT NULL,
        PRIMARY KEY  (id),
        UNIQUE KEY user_id (user_id)
    ) $charset_collate;";

    require_once( ABSPATH. 'wp-admin/includes/upgrade.php' );
    dbDelta( $sql );
}
register_activation_hook(__FILE__, 'wired_card_create_table');