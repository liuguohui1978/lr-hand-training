jQuery(document).ready(function($) {
    // 处理用户资料表单提交
    $('#wired-card-profile-form').on('submit', function(e) {
        e.preventDefault();
        
        // 验证必填字段
        const nickname = $('#nickname').val().trim();
        const childAge = parseInt($('#child_age').val());
        
        if (!nickname || isNaN(childAge)) {
            showMessage('请填写所有必填字段', 'error');
            return;
        }
        
        // 验证年龄范围
        if (childAge < 3 || childAge > 12) {
            showMessage('年龄必须在3-12岁之间', 'error');
            return;
        }
        
        // 准备数据
        const data = {
            action: 'wired_card_save_profile',
            nickname: nickname,
            child_age: childAge,
            city: $('#city').val().trim(),
            school: $('#school').val().trim(),
            _wpnonce: wiredCardProfile.nonce
        };
        
        // 发送AJAX请求
        $.post(wiredCardProfile.ajaxUrl, data, function(response) {
            if (response.success) {
                showMessage('资料保存成功，即将返回...', 'success');
                // 2秒后重定向回主系统
                setTimeout(() => {
                    window.location.href = '/lxtk/';
                }, 2000);
            } else {
                showMessage(response.data || '保存失败', 'error');
            }
        }).fail(function(xhr, status, error) {
            console.error('AJAX error:', status, error); // 调试输出
            showMessage('请求失败: ' + error, 'error');
        });
    });
    
    // 显示消息函数
    function showMessage(message, type) {
        const $messageDiv = $('.profile-message');
        $messageDiv.removeClass('error success').addClass(type).text(message);
        
        // 3秒后自动消失
        setTimeout(() => {
            $messageDiv.removeClass('error success').text('');
        }, 3000);
    }
});