// assets/js/admin-script.js
(function($) {
    'use strict';
    
    $(document).ready(function() {
        // 初始化媒体选择器
        var mediaUploader;
        
        // 缩略图选择器
        $('.select-thumbnail').on('click', function(e) {
            e.preventDefault();
            
            var button = $(this);
            var page = button.data('page');
            var previewContainer = button.parent().find('.thumbnail-preview');
            var thumbnailIdInput = button.parent().find('.thumbnail-id');
            
            // 创建文件输入元素
            var fileInput = $('<input type="file" accept="image/*" style="display:none;">');
            
            // 当文件被选择时
            fileInput.on('change', function() {
                var file = this.files[0];
                if (!file) return;
                
                // 创建临时URL预览
                var reader = new FileReader();
                reader.onload = function(e) {
                    previewContainer.html('<img src="'+ e.target.result +'" alt="预览" class="preview-image" />');
                    
                    // 上传文件
                    var formData = new FormData();
                    formData.append('file', file);
                    formData.append('action', 'wired_card_upload_thumbnail');
                    formData.append('page', page);
                    formData.append('nonce', wiredCardAdmin.nonce);
                    
                    $.ajax({
                        url: wiredCardAdmin.ajaxUrl,
                        type: 'POST',
                        data: formData,
                        processData: false,
                        contentType: false,
                        success: function(response) {
                            if (response.success) {
                                thumbnailIdInput.val(response.data.url);
                                saveThumbnailSetting(page, response.data.url);
                            }
                        }
                    });
                };
                reader.readAsDataURL(file);
            });
            
            // 触发文件选择
            fileInput.trigger('click');
        });
        
        // 移除缩略图
        $('.remove-thumbnail').on('click', function() {
            var button = $(this);
            var page = button.data('page');
            var previewContainer = button.parent().find('.thumbnail-preview');
            var thumbnailIdInput = button.parent().find('.thumbnail-id');
            
            // 重置预览
            previewContainer.html('<div class="no-preview">暂无预览</div>');
            
            // 清空ID
            thumbnailIdInput.val('');
            
            // 保存设置
            saveThumbnailSetting(page, '');
        });
        
        // 初始化管理页面图表
        initAdminChart();
    });
    
    // 保存缩略图设置
    function saveThumbnailSetting(page, thumbnailId) {
        $.ajax({
            url: wiredCardAdmin.ajaxUrl,
            type: 'POST',
            data: {
                action: 'wired_card_save_thumbnail',
                page: page,
                thumbnail_id: thumbnailId,
                nonce: wiredCardAdmin.nonce
            },
            success: function(response) {
                if (response.success) {
                    console.log('缩略图设置已保存');
                } else {
                    console.error('保存失败:', response.data.message);
                }
            },
            error: function() {
                console.error('网络错误');
            }
        });
    }
    
    // 初始化管理页面图表
    function initAdminChart() {
        if (!document.getElementById('admin-ranking-chart')) {
            return;
        }
        
        var ctx = document.getElementById('admin-ranking-chart').getContext('2d');
        
        // 获取数据
        $.ajax({
            url: wiredCardAdmin.ajaxUrl,
            type: 'POST',
            data: {
                action: 'wired_card_get_admin_stats',
                nonce: wiredCardAdmin.nonce
            },
            success: function(response) {
                if (response.success && response.data) {
                    var data = response.data;
                    
                    // 显示用户统计信息
                    var statsHtml = '<div class="user-stats-container">';
                    statsHtml += '<h3>用户统计</h3>';
                    statsHtml += '<div class="stats-grid">';
                    statsHtml += '<div class="stat-item"><span class="stat-label">总用户数:</span><span class="stat-value">' + (data.user_stats.total_users || 0) + '</span></div>';
                    statsHtml += '<div class="stat-item"><span class="stat-label">平均年龄:</span><span class="stat-value">' + (data.user_stats.avg_age ? data.user_stats.avg_age.toFixed(1) : 0) + '岁</span></div>';
                    statsHtml += '<div class="stat-item"><span class="stat-label">城市数量:</span><span class="stat-value">' + (data.user_stats.city_count || 0) + '</span></div>';
                    statsHtml += '</div></div>';
                    
                    $('#admin-stats-container').html(statsHtml);
                    
                    // 创建图表
                    new Chart(ctx, {
                        type: 'bar',
                        data: {
                            labels: data.labels,
                            datasets: [{
                                label: '完成次数',
                                data: data.completion_counts,
                                backgroundColor: 'rgba(76, 175, 80, 0.7)',
                                borderColor: 'rgba(76, 175, 80, 1)',
                                borderWidth: 1
                            }]
                        },
                        options: {
                            responsive: true,
                            maintainAspectRatio: false,
                            scales: {
                                y: {
                                    beginAtZero: true,
                                    suggestedMax: 50
                                }
                            },
                            plugins: {
                                legend: {
                                    display: false
                                }
                            },
                            layout: {
                                padding: {
                                    top: 20,
                                    bottom: 20
                                }
                            }
                        }
                    });
                }
            },
            error: function() {
                console.error('获取管理统计数据失败');
            }
        });
    }
    
    console.log('wp.media对象是否存在:', typeof wp.media !== 'undefined');
})(jQuery);