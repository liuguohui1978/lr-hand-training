// assets/js/script.js
(function($) {
    'use strict';
    
    // 初始化页面
    $(document).ready(function() {
        setupCardSystem();
    });
    
    // 设置图卡系统
    function setupCardSystem() {
        var currentPage = 1;
        var cardsPerPage = 10;
        
        // 初始化分页
        function initPagination() {
            // 隐藏所有卡片
            $('.card-item').hide();
            
            // 显示当前页卡片
            var startIndex = (currentPage - 1) * cardsPerPage;
            var endIndex = startIndex + cardsPerPage;
            $('.card-item').slice(startIndex, endIndex).show();
            
            // 更新分页按钮状态
            updatePaginationButtons();
        }
        
        // 更新分页按钮状态
        function updatePaginationButtons() {
            $('#prev-page').toggle(currentPage > 1);
            $('#next-page').toggle(currentPage < Math.ceil($('.card-item').length / cardsPerPage));
            $('#page-info').text('第 ' + currentPage + ' 页');
        }
        
        // 添加分页控制
        $('.wired-card-selector').append('<div class="pagination-controls">' +
            '<button id="prev-page" class="btn btn-secondary">上一页</button>' +
            '<span id="page-info"></span>' +
            '<button id="next-page" class="btn btn-secondary">下一页</button>' +
            '</div>');
            
        // 分页按钮事件
        $('#prev-page').on('click', function() {
            if (currentPage > 1) {
                currentPage--;
                initPagination();
            }
        });
        
        $('#next-page').on('click', function() {
            if (currentPage < Math.ceil($('.card-item').length / cardsPerPage)) {
                currentPage++;
                initPagination();
            }
        });
        
        // 初始化分页
        initPagination();
        
        // 打开图卡详情
        $('.open-card').on('click', function() {
            var page = $(this).data('page');
            openCardDetail(page);
        });
        
        // 关闭模态框
        $('.close-modal').on('click', function() {
            $('#card-detail-modal').hide();
        });
        
        // 点击模态框外部关闭
        $(window).on('click', function(e) {
            if (e.target == document.getElementById('card-detail-modal')) {
                $('#card-detail-modal').hide();
            }
        });
        
        // 只在存在排行榜图表容器时初始化
        if (document.getElementById('ranking-chart')) {
            initRankingChart();
        }
    }
    
    // 打开图卡详情
    function openCardDetail(page) {
        // 显示加载状态
        $('#modal-content-inner').html('<div class="loading">加载中...</div>');
        $('#card-detail-modal').show();
        
        // 获取图卡详情
        $.ajax({
            url: wiredCard.ajaxUrl,
            type: 'POST',
            data: {
                action: 'wired_card_get_card_detail',
                page: page,
                nonce: wiredCard.nonce
            },
            success: function(response) {
                if (response.success) {
                    renderCardDetail(response.data);
                } else {
                    $('#modal-content-inner').html('<div class="wired-card-error">'+ (response.data.message || '获取数据失败') +'</div>');
                }
            },
            error: function() {
                                    $('#modal-content-inner').html('<div class="wired-card-error">网络错误，请稍后再试</div>');
            }
        });
    }
    
    // 渲染图卡详情
    function renderCardDetail(data) {
        var html = '<div class="card-detail">';
        html += '<h2>第 '+ data.page +' 页</h2>';
        
        html += '<div class="card-image">';
        html += '<img src="'+ data.thumbnail_url +'" alt="第 '+ data.page +' 页">';
        html += '</div>';
        
        // 如果用户已有记录，显示记录
        if (data.user_record && Object.keys(data.user_record).length > 0) {
            html += '<div class="user-record">';
            html += '<h3>您的记录</h3>';
            html += '<p>错误: '+ data.user_record.error +'</p>';
            html += '<p>用时: '+ data.user_record.time +' 秒</p>';
            html += '<p>记录时间: '+ data.user_record.created_at +'</p>';
            html += '</div>';
        }
        
        // 记录表单 - 只在用户没有提交记录时显示
        if (!data.user_record || Object.keys(data.user_record).length === 0) {
            html += '<form class="record-form">';
            html += '<input type="hidden" name="page" value="'+ data.page +'">';
            
            html += '<div class="form-group">';
            html += '<label for="error">错误数</label>';
            html += '<input type="number" id="error" name="error" min="'+ wiredCard.errorMin +'" max="'+ wiredCard.errorMax +'" value="0" required>';
            html += '</div>';
            
            html += '<div class="form-group">';
            html += '<label for="time">用时(秒)</label>';
            html += '<input type="number" id="time" name="time" min="'+ wiredCard.timeMin +'" max="'+ wiredCard.timeMax +'" required>';
            html += '</div>';
            
            html += '<button type="submit" class="btn btn-primary">提交记录</button>';
            html += '</form>';
        }
        
        // 排行榜
        html += '<div class="card-ranking">';
        html += '<h3>本页排行榜</h3>';
        
        // 添加年龄筛选控件
        html += '<div class="modal-ranking-filter">';
        html += '<select id="modal-page-age-filter">';
        html += '<option value="all">全部年龄</option>';
        for (var i = 3; i <= 12; i++) {
            html += '<option value="'+i+'">'+i+'岁</option>';
        }
        html += '</select>';
        html += '</div>';
        
        html += '<table class="ranking-table">';
        html += '<tr><th>排名</th><th>学员昵称</th><th>年龄</th><th>错误数</th><th>用时(秒)</th></tr>';
        
        if (data.ranking.page_ranking && data.ranking.page_ranking.length > 0) {
            data.ranking.page_ranking.forEach(function(item, index) {
                html += '<tr>';
                html += '<td>'+ (index + 1) +'</td>';
                html += '<td>'+ item.nickname +'</td>';
                html += '<td>'+ (item.child_age || '--') +'</td>';
                html += '<td>'+ item.error +'</td>';
                html += '<td>'+ item.time +'</td>';
                html += '</tr>';
            });
        } else {
            html += '<tr><td colspan="5">暂无记录</td></tr>';
        }
        
        html += '</table>';
        html += '</div>';
        
        html += '</div>';
        
        $('#modal-content-inner').html(html);
        
        // 绑定模态框内的年龄筛选事件
        $('#modal-page-age-filter').on('change', function() {
            var age = $(this).val();
            $('.card-ranking .ranking-table tr').show();
            if (age !== 'all') {
                $('.card-ranking .ranking-table tr:not(:has(td:nth-child(3):contains('+age+')))').hide();
                $('.card-ranking .ranking-table tr:first').show(); // 保持表头显示
            }
        });
        
        // 设置表单提交事件
        $('.record-form').on('submit', function(e) {
            e.preventDefault();
            
            var formData = $(this).serializeArray();
            var data = {};
            
            formData.forEach(function(item) {
                data[item.name] = item.value;
            });
            
            // 验证输入
            if (!validateRecordData(data)) {
                return;
            }
            
            // 提交记录
            submitRecord(data);
        });
    }
    
    // 验证记录数据
    function validateRecordData(data) {
        var error = parseInt(data.error);
        var time = parseInt(data.time);
        
        if (isNaN(error) || error < wiredCard.errorMin || error > wiredCard.errorMax) {
            alert('错误数必须在 '+ wiredCard.errorMin +' 到 '+ wiredCard.errorMax +' 之间');
            return false;
        }
        
        if (isNaN(time) || time < wiredCard.timeMin || time > wiredCard.timeMax) {
            alert('用时必须在 '+ wiredCard.timeMin +' 到 '+ wiredCard.timeMax +' 秒之间');
            return false;
        }
        
        return true;
    }
    
    // 提交记录
    function submitRecord(data) {
        $.ajax({
            url: wiredCard.ajaxUrl,
            type: 'POST',
            data: {
                action: 'wired_card_submit',
                page: data.page,
                error: data.error,
                time: data.time,
                nonce: wiredCard.nonce
            },
            success: function(response) {
                if (response.success) {
                    alert('记录提交成功！');
                    openCardDetail(data.page);
                    updateRankingChart();
                } else {
                    alert(response.data.message || '提交记录失败');
                }
            },
            error: function() {
                alert('网络错误，请稍后再试');
            }
        });
    }
    
    // 初始化排行榜图表
    function initRankingChart(ageFilter) {
        // 获取排行榜数据
        $.ajax({
            url: wiredCard.ajaxUrl,
            type: 'POST',
            data: {
                action: 'wired_card_get_ranking',
                age: ageFilter || 'all',
                nonce: wiredCard.nonce
            },
            success: function(response) {
                if (response.success && response.data && response.data.total_ranking) {
                    renderRankingChart(response.data.total_ranking);
                    renderRankingTable(response.data.total_ranking);
                }
            },
            error: function() {
                // 错误处理
            }
        });
    }
    
    // 更新排行榜图表
    function updateRankingChart(ageFilter) {
        initRankingChart(ageFilter);
    }
    
    // 渲染排行榜图表
    function renderRankingChart(rankingData) {
        // 确保DOM完全加载
        if (document.readyState !== 'complete') {
            console.warn('DOM未完全加载，延迟执行图表渲染');
            setTimeout(function() {
                renderRankingChart(rankingData);
            }, 100);
            return;
        }
        
        // 检查Canvas元素是否存在且是有效的HTMLCanvasElement
        var chartCanvas = document.getElementById('ranking-chart');
        if (!chartCanvas || !(chartCanvas instanceof HTMLCanvasElement)) {
            console.error('排行榜图表容器未找到或不是Canvas元素，请检查HTML结构');
            // 尝试在1秒后重新检查
            setTimeout(function() {
                renderRankingChart(rankingData);
            }, 1000);
            return;
        }
        
        // 检查Chart.js库
        if (typeof Chart === 'undefined') {
            console.error('Chart.js库未加载，请确保已正确引入');
            // 尝试在1秒后重新检查
            setTimeout(function() {
                renderRankingChart(rankingData);
            }, 1000);
            return;
        }
        
        // 验证数据
        if (!rankingData || !Array.isArray(rankingData)) {
            console.error('无效的排行榜数据:', rankingData);
            return;
        }
        
        // 获取2D上下文
        var ctx;
        try {
            ctx = chartCanvas.getContext('2d');
            if (!ctx) {
                console.error('无法获取Canvas 2D上下文');
                // 尝试在1秒后重新获取
                setTimeout(function() {
                    renderRankingChart(rankingData);
                }, 1000);
                return;
            }
        } catch (e) {
            console.error('初始化图表上下文时出错:', e);
            // 尝试在1秒后重新获取
            setTimeout(function() {
                renderRankingChart(rankingData);
            }, 1000);
            return;
        }
        
        // 准备数据
        var labels = rankingData.map(function(item) {
            return item.nickname || '匿名';
        });
        
        var pagesData = rankingData.map(function(item) {
            return item.completed_pages || 0;
        });
        
        // 根据年龄筛选数据
        var ageFilter = $('#age-filter').val();
        if (ageFilter !== 'all') {
            labels = [];
            pagesData = [];
            
            rankingData.forEach(function(item) {
                if (item.child_age == ageFilter) {
                    labels.push(item.nickname || '匿名');
                    pagesData.push(item.completed_pages || 0);
                }
            });
        }
        
        // 如果已存在图表，销毁它
        if (window.rankingChart) {
            window.rankingChart.destroy();
        }
        
        // 创建新图表
        window.rankingChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: labels,
                datasets: [
                    {
                        label: '训练次数',
                        data: pagesData,
                        backgroundColor: 'rgba(255, 99, 132, 0.7)',
                        borderColor: 'rgba(255, 99, 132, 1)',
                        borderWidth: 1
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        title: {
                            display: true,
                            text: '完成页数'
                        }
                    }
                },
                animation: {
                    duration: 1000,
                    easing: 'easeOutQuart'
                }
            }
        });
    }
    
    // 渲染排行榜表格
    function renderRankingTable(rankingData) {
        // 添加年龄筛选控件
        var filterHtml = '<div class="ranking-filter">';
        filterHtml += '<select id="age-filter">';
        filterHtml += '<option value="all">全部年龄</option>';
        for (var i = 3; i <= 12; i++) {
            filterHtml += '<option value="'+i+'">'+i+'岁</option>';
        }
        filterHtml += '</select>';
        filterHtml += '</div>';
        
        var tableHtml = '<h3>连线图卡训练达人</h3><table class="ranking-table">';
        tableHtml += '<tr><th>排名</th><th>学员昵称</th><th>年龄</th><th>完成页数</th></tr>';
        
        if (rankingData && rankingData.length > 0) {
            rankingData.forEach(function(item, index) {
                tableHtml += '<tr>';
                tableHtml += '<td>'+ (index + 1) +'</td>';
                tableHtml += '<td>'+ (item.nickname || '--') +'</td>';
                tableHtml += '<td>'+ (item.child_age || '--') +'</td>';
                tableHtml += '<td>'+ item.completed_pages +'</td>';
                tableHtml += '</tr>';
            });
        } else {
            tableHtml += '<tr><td colspan="4">暂无记录</td></tr>';
        }
        
        tableHtml += '</table>';
        
        $('#ranking-table').html(filterHtml + tableHtml);
        
        // 设置筛选事件
        $('#age-filter').on('change', function() {
            var selectedAge = $(this).val();
            updateRankingChart(selectedAge);
        });
    }
    
})(jQuery);