<?php
/**
 * Plugin Name: 方位判断训练
 * Description: 儿童空间知觉能力训练工具
 * Version: 1.2.1
 * Author: 刘国辉
 */

defined('ABSPATH') or die('禁止直接访问');

define('DIRECTION_JUDGMENT_VERSION', '1.2.1');
define('DIRECTION_JUDGMENT_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('DIRECTION_JUDGMENT_PLUGIN_URL', plugin_dir_url(__FILE__));

require_once DIRECTION_JUDGMENT_PLUGIN_DIR . 'includes/admin.php';
require_once DIRECTION_JUDGMENT_PLUGIN_DIR . 'includes/frontend.php';

register_activation_hook(__FILE__, 'direction_judgment_create_tables');

function direction_judgment_create_tables() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'direction_judgment_results';
    
    $sql = "CREATE TABLE $table_name (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        user_id bigint(20) NOT NULL,
        username varchar(50) NOT NULL,
        phone varchar(20),
        rounds int(11) NOT NULL,
        correct int(11) NOT NULL,
        wrong int(11) NOT NULL,
        time_taken int(11) NOT NULL,
        accuracy float NOT NULL,
        created_at datetime DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY  (id)
    ) ".$wpdb->get_charset_collate().";";
    
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
    
    add_option('direction_judgment_rounds', 50);
    add_option('direction_judgment_prompt', '请根据箭头指的方向选择正确的按钮');
}

add_shortcode('direction_judgment', 'direction_judgment_shortcode');

function direction_judgment_shortcode() {
    ob_start();
    direction_judgment_display_game();
    return ob_get_clean();
}

add_action('wp_enqueue_scripts', 'direction_judgment_enqueue_scripts');

function direction_judgment_enqueue_scripts() {
    // 加载符号字体
    wp_enqueue_style(
        'direction-judgment-symbols',
        'https://fonts.googleapis.com/css2?family=Noto+Sans+Symbols+2&display=swap',
        array(),
        DIRECTION_JUDGMENT_VERSION
    );
    
    wp_enqueue_style(
        'direction-judgment-style',
        DIRECTION_JUDGMENT_PLUGIN_URL . 'assets/css/style.css',
        array(),
        DIRECTION_JUDGMENT_VERSION
    );
    
    wp_enqueue_script(
        'direction-judgment-script',
        DIRECTION_JUDGMENT_PLUGIN_URL . 'assets/js/script.js',
        array('jquery'),
        DIRECTION_JUDGMENT_VERSION,
        true
    );
    
    wp_localize_script('direction-judgment-script', 'directionJudgment', array(
        'ajaxurl' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('direction_judgment_nonce'),
        'rounds' => get_option('direction_judgment_rounds', 50)
    ));
}

add_action('wp_ajax_save_direction_result', 'direction_judgment_save_result');
add_action('wp_ajax_nopriv_save_direction_result', 'direction_judgment_save_result');

function direction_judgment_save_result() {
    check_ajax_referer('direction_judgment_nonce', 'nonce');
    
    $user_id = get_current_user_id();
    $username = $user_id ? wp_get_current_user()->display_name : '访客';
    $phone = isset($_POST['phone']) ? sanitize_text_field($_POST['phone']) : '';
    $rounds = intval($_POST['rounds']);
    $correct = intval($_POST['correct']);
    $wrong = intval($_POST['wrong']);
    $time_taken = intval($_POST['time_taken']);
    $accuracy = $rounds > 0 ? ($correct / $rounds) * 100 : 0;
    
    global $wpdb;
    $table_name = $wpdb->prefix . 'direction_judgment_results';
    
    $wpdb->insert($table_name, array(
        'user_id' => $user_id,
        'username' => $username,
        'phone' => $phone,
        'rounds' => $rounds,
        'correct' => $correct,
        'wrong' => $wrong,
        'time_taken' => $time_taken,
        'accuracy' => $accuracy
    ));
    
    wp_send_json_success(array('message' => '结果已保存'));
}