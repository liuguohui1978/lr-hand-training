jQuery(document).ready(function($) {
    // 方向定义 - 使用更可靠的Unicode字符
    const directions = ['上', '下', '左', '右', '左上', '左下', '右上', '右下'];
    const directionSymbols = {
        '上': '⬆',       // U+2B06
        '下': '⬇',       // U+2B07
        '左': '⬅',       // U+2B05
        '右': '➡',       // U+27A1
        '左上': '↖',     // U+2196
        '左下': '↙',     // U+2199
        '右上': '↗',     // U+2197
        '右下': '↘'      // U+2198
    };
    
    // 游戏状态
    let currentDirection = '';
    let correctCount = 0;
    let wrongCount = 0;
    let currentRound = 0;
    let totalRounds = parseInt(directionJudgment.rounds);
    let startTime = 0;
    let timerInterval = null;
    let timeTaken = 0;
    let isGameRunning = false;
    
    // DOM元素
    const $startBtn = $('#startGameBtn');
    const $restartBtn = $('#restartGameBtn');
    const $gameContent = $('#gameContent');
    const $directionArrow = $('#directionArrow');
    const $directionOptions = $('.direction-btn');
    const $currentRound = $('#currentRound');
    const $correctCount = $('#correctCount');
    const $wrongCount = $('#wrongCount');
    const $timeTaken = $('#timeTaken');
    const $gameResult = $('#gameResult');
    const $finalAccuracy = $('#finalAccuracy');
    const $finalTime = $('#finalTime');
    const $userPhone = $('#userPhone');
    const $leaderboardBody = $('#leaderboardBody');
    
    // 初始化显示总轮数
    $('#totalRounds').text(totalRounds);
    
    // 开始游戏
    $startBtn.on('click', function() {
        $(this).fadeOut(300, function() {
            $gameContent.css('display', 'flex').hide().fadeIn(400, function() {
                startGame();
            });
        });
    });
    
    // 重新开始
    $restartBtn.on('click', function() {
        $gameResult.fadeOut(300, function() {
            resetGame();
            $gameContent.show();
            $startBtn.fadeIn(300);
        });
    });
    
    // 方向按钮点击
    $directionOptions.on('click', function() {
        if (!isGameRunning) return;
        
        const selectedDirection = $(this).data('direction');
        const isCorrect = selectedDirection === currentDirection;
        
        // 视觉反馈
        if (isCorrect) {
            $(this).css({
                'background': '#5cb85c',
                'transform': 'scale(1.05)'
            });
            correctCount++;
            $correctCount.text(correctCount);
        } else {
            $(this).css({
                'background': '#d9534f',
                'transform': 'scale(0.95)'
            });
            // 高亮正确答案
            $(`.direction-btn[data-direction="${currentDirection}"]`).css({
                'background': '#5cb85c',
                'transform': 'scale(1.05)'
            });
            wrongCount++;
            $wrongCount.text(wrongCount);
        }
        
        currentRound++;
        $currentRound.text(currentRound);
        
        // 下一轮或结束
        setTimeout(() => {
            if (currentRound >= totalRounds) {
                endGame();
            } else {
                resetButtonsState();
                showNextDirection();
            }
        }, 800);
    });
    
    /* ========== 核心函数 ========== */
    
    function startGame() {
        resetGame();
        isGameRunning = true;
        startTime = new Date().getTime();
        timerInterval = setInterval(updateTimer, 1000);
        showNextDirection();
    }
    
    function resetGame() {
        currentRound = 0;
        correctCount = 0;
        wrongCount = 0;
        timeTaken = 0;
        isGameRunning = false;
        
        $currentRound.text(currentRound);
        $correctCount.text(correctCount);
        $wrongCount.text(wrongCount);
        $timeTaken.text(timeTaken);
        
        clearInterval(timerInterval);
        resetButtonsState();
    }
    
    function showNextDirection() {
        if (!isGameRunning) return;
        
        // 随机方向
        currentDirection = directions[Math.floor(Math.random() * directions.length)];
        
        // 更可靠的箭头更新
        $directionArrow
            .css({
                'transform': 'scale(0.5)',
                'opacity': '0'
            })
            .text(directionSymbols[currentDirection])
            .animate({
                'opacity': '1',
                'transform': 'scale(1)'
            }, 300);
        
        // 准备选项
        const options = [currentDirection];
        while (options.length < 4) {
            const randomDir = directions[Math.floor(Math.random() * directions.length)];
            if (!options.includes(randomDir)) {
                options.push(randomDir);
            }
        }
        
        // 打乱选项
        shuffleArray(options);
        
        // 更新按钮
        $directionOptions.each(function(index) {
            $(this)
                .data('direction', options[index])
                .text(options[index])
                .css({
                    'transform': 'scale(1)',
                    'opacity': '0'
                })
                .animate({
                    'opacity': '1'
                }, 300);
        });
    }
    
    function endGame() {
        isGameRunning = false;
        clearInterval(timerInterval);
        timeTaken = Math.floor((new Date().getTime() - startTime) / 1000);
        
        const accuracy = (correctCount / totalRounds) * 100;
        $finalAccuracy.text(accuracy.toFixed(1));
        $finalTime.text(timeTaken);
        
        // 保存结果
        saveResult();
    }
    
    function saveResult() {
        const phone = $userPhone.val() || '';
        
        $.ajax({
            url: directionJudgment.ajaxurl,
            type: 'POST',
            data: {
                action: 'save_direction_result',
                nonce: directionJudgment.nonce,
                phone: phone,
                rounds: totalRounds,
                correct: correctCount,
                wrong: wrongCount,
                time_taken: timeTaken
            },
            beforeSend: function() {
                $restartBtn.prop('disabled', true);
            },
            success: function(response) {
                if (response.success) {
                    $gameContent.fadeOut(300, function() {
                        $gameResult.fadeIn(400);
                    });
                    refreshLeaderboard();
                }
            },
            complete: function() {
                $restartBtn.prop('disabled', false);
            }
        });
    }
    
    function refreshLeaderboard() {
        $.get(window.location.href, function(data) {
            const newContent = $(data).find('#leaderboardBody').html();
            $leaderboardBody.html(newContent);
        });
    }
    
    function updateTimer() {
        timeTaken = Math.floor((new Date().getTime() - startTime) / 1000);
        $timeTaken.text(timeTaken);
    }
    
    function resetButtonsState() {
        $directionOptions.css({
            'background': '#4CAF50',
            'transform': 'scale(1)'
        });
    }
    
    function shuffleArray(array) {
        for (let i = array.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [array[i], array[j]] = [array[j], array[i]];
        }
        return array;
    }
});