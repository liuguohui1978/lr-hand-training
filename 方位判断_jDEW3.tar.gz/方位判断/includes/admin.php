<?php
add_action('admin_menu', 'direction_judgment_admin_menu');

function direction_judgment_admin_menu() {
    add_options_page(
        '方位判断设置',
        '方位判断',
        'manage_options',
        'direction-judgment-settings',
        'direction_judgment_settings_page'
    );
    
    add_menu_page(
        '方位判断结果',
        '方位判断',
        'manage_options',
        'direction-judgment-results',
        'direction_judgment_results_page',
        'dashicons-location-alt'
    );
}

function direction_judgment_settings_page() {
    if (!current_user_can('manage_options')) {
        return;
    }
    
    if (isset($_POST['direction_judgment_rounds'])) {
        check_admin_referer('direction_judgment_settings');
        update_option('direction_judgment_rounds', intval($_POST['direction_judgment_rounds']));
        update_option('direction_judgment_prompt', sanitize_text_field($_POST['direction_judgment_prompt']));
        echo '<div class="notice notice-success"><p>设置已保存!</p></div>';
    }
    
    $rounds = get_option('direction_judgment_rounds', 50);
    $prompt = get_option('direction_judgment_prompt', '请根据箭头指的方向选择正确的按钮');
    ?>
    <div class="wrap">
        <h1>方位判断设置</h1>
        <form method="post">
            <?php wp_nonce_field('direction_judgment_settings'); ?>
            <table class="form-table">
                <tr>
                    <th scope="row"><label for="direction_judgment_rounds">每轮训练次数</label></th>
                    <td>
                        <input type="number" id="direction_judgment_rounds" name="direction_judgment_rounds" 
                               value="<?php echo esc_attr($rounds); ?>" min="1" max="100">
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="direction_judgment_prompt">训练提示语</label></th>
                    <td>
                        <input type="text" id="direction_judgment_prompt" name="direction_judgment_prompt" 
                               value="<?php echo esc_attr($prompt); ?>" style="width: 400px;">
                    </td>
                </tr>
            </table>
            <?php submit_button('保存设置'); ?>
        </form>
    </div>
    <?php
}

function direction_judgment_results_page() {
    if (!current_user_can('manage_options')) {
        return;
    }
    
    global $wpdb;
    $table_name = $wpdb->prefix . 'direction_judgment_results';
    
    $search = isset($_GET['s']) ? sanitize_text_field($_GET['s']) : '';
    $where = '';
    
    if ($search) {
        $where = $wpdb->prepare("
            WHERE username LIKE %s OR 
            phone LIKE %s OR 
            user_id = %d",
            '%' . $wpdb->esc_like($search) . '%',
            '%' . $wpdb->esc_like($search) . '%',
            is_numeric($search) ? intval($search) : 0
        );
    }
    
    $per_page = 20;
    $total_items = $wpdb->get_var("SELECT COUNT(*) FROM $table_name $where");
    $current_page = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;
    $offset = ($current_page - 1) * $per_page;
    
    $results = $wpdb->get_results("
        SELECT * FROM $table_name 
        $where 
        ORDER BY created_at DESC 
        LIMIT $per_page OFFSET $offset
    ");
    
    ?>
    <div class="wrap">
        <h1>方位判断结果</h1>
        
        <form method="get">
            <input type="hidden" name="page" value="direction-judgment-results">
            <p class="search-box">
                <input type="search" name="s" value="<?php echo esc_attr($search); ?>" placeholder="搜索用户名/手机号/ID">
                <?php submit_button('搜索', 'button', '', false); ?>
            </p>
        </form>
        
        <div class="tablenav top">
            <div class="tablenav-pages">
                <?php
                echo paginate_links(array(
                    'base' => add_query_arg('paged', '%#%'),
                    'format' => '',
                    'prev_text' => '&laquo;',
                    'next_text' => '&raquo;',
                    'total' => ceil($total_items / $per_page),
                    'current' => $current_page
                ));
                ?>
            </div>
        </div>
        
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>用户名</th>
                    <th>手机号</th>
                    <th>轮数</th>
                    <th>正确</th>
                    <th>错误</th>
                    <th>用时(秒)</th>
                    <th>正确率</th>
                    <th>日期</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($results) : ?>
                    <?php foreach ($results as $result) : ?>
                        <tr>
                            <td><?php echo $result->id; ?></td>
                            <td><?php echo esc_html($result->username); ?></td>
                            <td><?php echo esc_html($result->phone); ?></td>
                            <td><?php echo $result->rounds; ?></td>
                            <td><?php echo $result->correct; ?></td>
                            <td><?php echo $result->wrong; ?></td>
                            <td><?php echo $result->time_taken; ?></td>
                            <td><?php echo number_format($result->accuracy, 1); ?>%</td>
                            <td><?php echo date('Y-m-d H:i', strtotime($result->created_at)); ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php else : ?>
                    <tr>
                        <td colspan="9">没有找到结果</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?php
}