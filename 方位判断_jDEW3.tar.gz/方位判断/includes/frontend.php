<?php
function direction_judgment_display_game() {
    if (!is_admin()) {
        // 添加字体预加载
        echo '<style>
        @import url(\'https://fonts.googleapis.com/css2?family=Noto+Sans+Symbols+2&display=swap\');
        </style>';
        
        $prompt = get_option('direction_judgment_prompt', '请根据箭头指的方向选择正确的按钮');
        ?>
        <div class="direction-judgment-container">
            <div class="direction-judgment-game">
                <div class="direction-prompt">
                    <?php echo esc_html($prompt); ?>
                </div>
                
                <div class="direction-start">
                    <button id="startGameBtn">开始训练</button>
                </div>
                
                <div id="gameContent" style="display:none;">
                    <div class="direction-arrow-container">
                        <div class="direction-arrow" id="directionArrow">⬆</div>
                    </div>
                    
                    <div class="direction-options-container">
                        <div class="direction-options-row" id="directionOptions">
                            <button class="direction-btn" data-direction=""></button>
                            <button class="direction-btn" data-direction=""></button>
                            <button class="direction-btn" data-direction=""></button>
                            <button class="direction-btn" data-direction=""></button>
                        </div>
                    </div>
                    
                    <div class="direction-stats">
                        <div>进度: <span id="currentRound">0</span>/<span id="totalRounds"><?php echo esc_html(get_option('direction_judgment_rounds', 50)); ?></span></div>
                        <div>正确: <span id="correctCount">0</span></div>
                        <div>错误: <span id="wrongCount">0</span></div>
                        <div>用时: <span id="timeTaken">0</span>秒</div>
                    </div>
                </div>
                
                <div class="direction-result" id="gameResult" style="display:none;">
                    <h3>训练完成!</h3>
                    <p>正确率: <span id="finalAccuracy">0</span>%</p>
                    <p>用时: <span id="finalTime">0</span>秒</p>
                    <div id="userInfoForm" style="<?php echo is_user_logged_in() ? 'display:none;' : ''; ?>">
                        <input type="text" id="userPhone" placeholder="手机号(可选)">
                    </div>
                    <button id="restartGameBtn">重新开始</button>
                </div>
            </div>
            
            <div class="direction-leaderboard">
                <h3>排行榜</h3>
                <table>
                    <thead>
                        <tr>
                            <th>用户名</th>
                            <th>用时</th>
                            <th>正确率</th>
                            <th>日期</th>
                        </tr>
                    </thead>
                    <tbody id="leaderboardBody">
                        <?php direction_judgment_display_leaderboard(); ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php
    }
}

function direction_judgment_display_leaderboard() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'direction_judgment_results';
    
    $results = $wpdb->get_results("
        SELECT username, time_taken, accuracy, created_at 
        FROM $table_name 
        ORDER BY accuracy DESC, time_taken ASC 
        LIMIT 10
    ");
    
    if ($results) {
        foreach ($results as $result) {
            echo '<tr>';
            echo '<td>' . esc_html($result->username) . '</td>';
            echo '<td>' . esc_html($result->time_taken) . '秒</td>';
            echo '<td>' . esc_html(number_format($result->accuracy, 1)) . '%</td>';
            echo '<td>' . esc_html(date('Y-m-d', strtotime($result->created_at))) . '</td>';
            echo '</tr>';
        }
    } else {
        echo '<tr><td colspan="4">暂无数据</td></tr>';
    }
}